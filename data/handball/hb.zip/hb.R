> wdir <- "C:/Users/vlado/work/OpenAlex/API/handball3"
> setwd(wdir)
> library(httr)
> library(jsonlite)
> source("https://raw.githubusercontent.com/bavla/OpenAlex/main/code/OpenAlex2.R")

> Q <- list(
+   search="handball",
+   # filter="author.id:A5001676164",
+   select=selCite,
+   per_page="200"
+ )
> OpenAlex2PajekCite(Q,1,name="HBcite",step=500,prop=TRUE)


> Q <- list(
+   search="handball",
+   select=selCite,
+   per_page="200"
+ )
> # source("../OpenAlex4.R")
> source("https://raw.githubusercontent.com/bavla/OpenAlex/main/code/OpenAlex4.R")
> OpenAlex2PajekCite(Q,1,name="HBcite",step=500,prop=TRUE)


    works[[Wid]] <- list(wind=length(works)+1,cnt=0,inp=0,out=0,py=NA,cbc=0,
      typ=NA,lan=NA,cdc=0,sWname=NA)


==================================================================


setDic <- function(dic,did,att,val)
  if(!is.null(val)) dic[[did]][[att]] <- val

  setDic(works,Wid,"py",pYear); setDic(works,Wid,"typ",type)
  setDic(works,Wid,"cbc",cbc); setDic(works,Wid,"cdc",cdc)
  setDic(works,Wid,"out",length(refs)); setDic(works,Wid,"lan",lang)
> 

===================================================================

> test <<- eDict()
> test[["ena"]] <- list(i=1,a="aaaaa",b=3)
> test[["dva"]] <- list(i=2,b=7,a="bbbbb")
> test[["tri"]] <- list(i=3,a="ccccc",b=5)
> TU <- dict2DF(test,"i")


